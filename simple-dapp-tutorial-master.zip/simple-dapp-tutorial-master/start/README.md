# MetaMask Test Dapp

This is a simple test dapp for use in MetaMask e2e tests.

Currently hosted [here](https://metamask.github.io/test-dapp/).

## NOTE: Requires Manual Deployment
After merging or pushing to `master`, please `yarn deploy` in the project root
directory if any of the following files have changed:

- `contract.js`
- `index.html`
